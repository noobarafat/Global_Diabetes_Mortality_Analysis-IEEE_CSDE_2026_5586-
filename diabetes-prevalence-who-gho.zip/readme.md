# Prevalence rate of diabetes in adults - Data package

This data package contains the data that powers the chart ["Prevalence rate of diabetes in adults"](https://ourworldindata.org/grapher/diabetes-prevalence-who-gho?v=1&csvType=full&useColumnShortNames=false) on the Our World in Data website. It was downloaded on June 25, 2026.

### Active Filters

A filtered subset of the full data was downloaded. The following filters were applied:

## CSV Structure

The high level structure of the CSV file is that each row is an observation for an entity (usually a country or region) and a timepoint (usually a year).

The first two columns in the CSV file are "Entity" and "Code". "Entity" is the name of the entity (e.g. "United States"). "Code" is the OWID internal entity code that we use if the entity is a country or region. For most countries, this is the same as the [iso alpha-3](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3) code of the entity (e.g. "USA") - for non-standard countries like historical countries these are custom codes.

The third column is either "Year" or "Day". If the data is annual, this is "Year" and contains only the year as an integer. If the column is "Day", the column contains a date string in the form "YYYY-MM-DD".

The final column is the data column, which is the time series that powers the chart. If the CSV data is downloaded using the "full data" option, then the column corresponds to the time series below. If the CSV data is downloaded using the "only selected data visible in the chart" option then the data column is transformed depending on the chart type and thus the association with the time series might not be as straightforward.


## Metadata.json structure

The .metadata.json file contains metadata about the data package. The "charts" key contains information to recreate the chart, like the title, subtitle etc.. The "columns" key contains information about each of the columns in the csv, like the unit, timespan covered, citation for the data etc..

## About the data

Our World in Data is almost never the original producer of the data - almost all of the data we use has been compiled by others. If you want to re-use data, it is your responsibility to ensure that you adhere to the sources' license and to credit them correctly. Please note that a single time series may have more than one source - e.g. when we stich together data from different time periods by different producers or when we calculate per capita metrics using population data from a second source.

## Detailed information about the data


## Raised fasting blood glucose (>=7.0 mmol/L) (age-standardized estimate) - Sex: both sexes - Age group: 18+  years of age
Last updated: May 22, 2026  
Next update: May 2027  
Date range: 1980–2014  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
World Health Organization - Global Health Observatory (2026) – with minor processing by Our World in Data

#### Full citation
World Health Organization - Global Health Observatory (2026) – with minor processing by Our World in Data. “Raised fasting blood glucose (>=7.0 mmol/L) (age-standardized estimate) - Sex: both sexes - Age group: 18+  years of age – WHO” [dataset]. World Health Organization, “Global Health Observatory” [original data].
Source: World Health Organization - Global Health Observatory (2026) – with minor processing by Our World In Data

### How is this data described by its producer - World Health Organization - Global Health Observatory (2026)?
#### Rationale
To assess the level of treatment with glucose-lowering medication among people with diabetes

#### Definition
Percentage of people aged ≥ 30 years with diabetes who are currently using glucose-lowering medication. Diabetes is defined as FPG ≥7.0 mmol/L, or HbA1c ≥6.5%, or taking medication for diabetes.

#### Method of measurement
Estimated from population-based surveys as follows: **Numerator:** number of adults aged ≥ 30 years with diabetes who are currently taking glucose-lowering medication **Denominator:** total number of adults aged ≥ 30 years with diabetes, defined as fasting plasma glucose (FPG) ≥7.0 mmol/L, glycated haemoglobin (HbA1c) ≥6.5%, or taking medication for diabetes. Whether a person is taking glucose-lowering medication for diabetes is assessed using survey-specific questions worded as variations of “are you currently taking medication for diabetes or high blood sugar?”; or the combination of “do you currently inject/use insulin for diabetes?” and “are you currently taking any medicines, tablets, or pills for diabetes?”; or using information gathered on prescribed medicines.

#### Method of estimation
Population-representative studies with measurements of fasting glucose and/or glycated haemoglobin (HbA1c), and information on diabetes treatment were compiled. Data were pooled using a Bayesian hierarchical meta-regression model to estimate diabetes treatment coverage. Age-standardized estimates are produced by weighting the age-specific estimates by the product of the WHO Standard Population fraction and the age-specific prevalence of diabetes. Full details of input data and methods are available at: NCD Risk Factor Collaboration (NCD-RisC). Worldwide trends in diabetes prevalence and treatment from 1990 to 2022: a pooled analysis of 1108 population-representative studies with 141 million participants. Lancet 2024. Available online at: https://doi.org/10.1016/S0140-6736(24)02317-1

### Source

#### World Health Organization – Global Health Observatory
Retrieved on: 2026-05-22  
Retrieved from: https://www.who.int/data/gho  


    